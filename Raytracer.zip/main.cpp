#include "Renderer.h"
#include "Camera.h"
#include "ExampleScene.h"

using namespace std;

int main()
{
	Raytracer* raytracer = new Raytracer();

	CameraConfiguration cameraConfig;
	cameraConfig.imageWidth = 1200;
	cameraConfig.aspectRatio = 16.0f / 9.0f;
	cameraConfig.samplesPerPixel = 500;
	cameraConfig.maxDepth = 50;

	cameraConfig.fov = 20;
	cameraConfig.position = Vec3(13.0f, 2.0f, 3.0f);
	cameraConfig.lookAt = Vec3(0.0f, 0.0f, 0.0f);
	cameraConfig.vUp = Vec3(0.0f, 1.0f, 0.0f);

	cameraConfig.defocusAngle = 0.6f;
	cameraConfig.focusDistance = 10.0f;

	Camera* camera = new Camera(cameraConfig);

	ExampleScene* exampleScene = new ExampleScene();
	exampleScene->Create();

	raytracer->Render(camera, exampleScene);

	delete exampleScene;
	exampleScene = nullptr;

	delete camera;
	camera = nullptr;

	delete raytracer;
	raytracer = nullptr;

	return 0;
}
